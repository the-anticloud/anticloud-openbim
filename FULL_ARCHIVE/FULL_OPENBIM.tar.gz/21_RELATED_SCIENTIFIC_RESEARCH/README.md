# 21 Related Scientific Research

**Project:** OPENBIM
**Upstream:** https://github.com/openBIM/openBIM

Content specific to OPENBIM in category ARCHITECTURAL_DESIGN.
