# Result Register

**Project:** OPENBIM

| Result | Pass Condition | Command | Observed | Status |
| --- | --- | --- | --- | --- |
| (none yet) | (define before running) | (verbatim) | (unrecorded) | NOT RUN |
